% first pair of input frames
K = [517.3 0 318.6;	0 516.5 255.3; 0 0 1];
c2 = double(imreadbw('rgb/1305031102.175304.png'));
c1 = double(imreadbw('rgb/1305031102.275326.png'));
d2 = double(imread('depth/1305031102.160407.png'))/5000;
d1 = double(imread('depth/1305031102.262886.png'))/5000;
% result:
% approximately  -0.0018    0.0065    0.0369   -0.0287   -0.0184   -0.0004

% second pair of input frames
% K = [ 535.4  0 320.1;	0 539.2 247.6; 0 0 1];
% c1 = double(imreadbw('rgb/1341847980.722988.png'));
% c2 = double(imreadbw('rgb/1341847982.998783.png'));
% d1 = double(imread('depth/1341847980.723020.png'))/5000;
% d2 = double(imread('depth/1341847982.998830.png'))/5000;
% result:
% approximately  0.2979   -0.0106    0.0452   -0.0041   -0.0993   -0.0421


% TODO

