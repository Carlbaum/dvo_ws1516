function [ err ] = calcErr( IRef, DRef, I, xi, K )
    %TODO
end

