function [ Jac, residual ] = deriveErrAnalytic( IRef, DRef, I, xi, K )
    % calculate analytic derivates
    % TODO

end

