function [ Id, Dd, Kd ] = downscale( I, D, K, level )
    % TODO

end