function [ Jac, residual ] = deriveErrNumeric( IRef, DRef, I, xi, K )
    % calculate numeric derivative. SLOW
    % TODO
    
end

